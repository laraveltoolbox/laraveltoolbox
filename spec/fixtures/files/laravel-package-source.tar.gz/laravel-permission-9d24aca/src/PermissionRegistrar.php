<?php

namespace Spatie\Permission;

class PermissionRegistrar
{
    /** @var array<string, string> */
    protected array $permissions = [];

    public function register(string $ability, string $handler): void
    {
        $this->permissions[$ability] = $handler;
    }
}
