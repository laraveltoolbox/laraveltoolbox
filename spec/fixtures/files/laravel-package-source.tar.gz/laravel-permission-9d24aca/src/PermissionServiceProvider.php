<?php

namespace Spatie\Permission;

use Illuminate\Support\ServiceProvider;

/**
 * Registers the package with the laravel application.
 */
class PermissionServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Bind the permission registrar as a singleton
        $this->app->singleton(PermissionRegistrar::class);
    }

    public function boot(): void
    {
        $this->publishes([
            __DIR__ . '/../config/permission.php' => config_path('permission.php'),
        ], 'config');
    }
}
