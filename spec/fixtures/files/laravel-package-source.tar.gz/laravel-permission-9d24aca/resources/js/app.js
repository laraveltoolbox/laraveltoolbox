// Bootstraps the permission UI
export function can(ability) {
  return window.permissions.includes(ability)
}
